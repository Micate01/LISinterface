﻿/*************************************
 * 名称：迪瑞.BF6800解析程序
 * 功能：血常规五分类解析程序
 * 作者：谢天
 * 时间：2017-02-21
 * 修改时间:2019-04-04
 * 修改内容:支持迪瑞BF6900 同时支持双向通信
 * 通讯类型：网络
 * 备注:应答符见配置文件BF6800.txt  
 * ***********************************/
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Text.RegularExpressions;
using ZLCHSLisComm;
using System.Collections;
using System.IO;
using System.Xml;
using System.Data.OracleClient;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;


namespace ZLCHSLis.Dirui.BF6900
{
    public class ResolveResult : IDataResolve
    {
        public string strInstrument_id;
        public string strSubBegin;  //多帧开始位
        public string strSubEnd;    //多帧结束位
        public string strDetype;    //解析方式 
        public string strDataBegin;  //数据开始位
        public string strDataEnd;                 //数据结束位
        public string strACK_all;                  //全部应答
        public string strACK_term;                 //条件应答
        public List<string> listInputResult = new List<string>();
        public List<string> ListImagePosition = new List<string>();              //图像存放位置
        public Boolean ImmediatelyUpdate = false;                               //立即更新
        Mindray may = new Mindray();
        DataSetHandle dsHandle = new DataSetHandle();
        Write_Log writelog = new Write_Log();
        SaveResult saveResult;
        string TestResultValue;      //解析后的通用字符串
        string strDevice;
        string strDeviceID;
        List<string> TestGraph; //图像列表
        DataRow DrTestTimeSignField;         //检验时间标识
        DataRow DrTestTimeField;             //检验时间
        DataRow DrSampleNoSignField;         //常规样本号标识
        DataRow DrSampleNoField;             //常规样本号
        DataRow DrBarCodeSignField;             //条码号标识
        DataRow DrBarCodeField;              //条码号
        DataRow DrSampleTypeSignField;       //样本类型标识
        DataRow DrSampleTypeField;           //样本类型
        DataRow DrOperatorSignField;       //检验人标识
        DataRow DrOperatorField;           //检验人
        DataRow DrSpecimenSignField;       //标本标识
        DataRow DrSpecimenField;           //标本
        DataRow DrResultSignField;           //结果标识
        DataRow DrResultInfoField;           //结果信息
        DataRow DrResultCountField;          //结果数
        DataRow DrSingleResultField;         //单个结果
        DataRow DrChannelField;              //通道号
        DataRow DrResultField;               //结果值
        DataRow DrQCSampleField;             //质控样本号
        string strTestTime; //检验时间
        string strSampleNo;//标本号
        string strBarCode;  //条码
        string strOperator; //检验医师
        string strSampleType; //检验类型
        string StrSpecimen;   //标本类型
        string FilePath = "";
        Boolean ResultFlag;                 //结果开始标志
        string subString;                    //临时存放解析字符串
        DataRow[] FindRow;                  //解析设置
        DataSet ds_ItemChannel = new DataSet();
        DataTable tItemChannel = new DataTable();
        Dictionary<String, String> _DIC = new Dictionary<String, String>();
        public void ParseResult()
        {

            throw new NotImplementedException();
        }

        public void ParseResult(string strSource, ref string strResult, ref string strReserved, ref string strCmd)
        {
            string strTestFullTime = DateTime.Now.ToString("yyyyMMddHHmmss");
            char CR = Convert.ToChar(13);//换行符
            char SB = Convert.ToChar(11);//开始符
            char EB = Convert.ToChar(28);//结束符
            string strTestTime = ""; //检验时间
            string strSampleNo = "";//标本号
            string strBarCode = "";  //条码
            string MsgHead = "" + SB;
            string MsgEnd = EB + "" + CR;
            StringBuilder sBuilder = new StringBuilder();
            string sql = "";
            List<string> TestGraph = new List<string>(); //图像列表
            //图形变量定义
            string RBC = "";
            string PLT = "";
            string BASO = "";
            string DIFF = "";
            string path = @"c:\";
            string imageName = "";
            try
            {
                if (strSource.StartsWith(MsgHead) && strSource.EndsWith(MsgEnd))
                {
                    StreamReader reader = new StreamReader(@".\Dirui.BF6900.txt", Encoding.Default);
                    string correspondence = reader.ReadLine();
                    reader.Close();
                    string[] correspondenceArray = correspondence.Split('|');
                    writelog.Write(strDevice, "全部数据:" + strSource, "log");
                    //处理含有多个消息的情况
                    strSource = strSource.Replace(MsgHead, "");
                    string mulSplit = "MSH";
                    string[] strSourceMul = strSource.Split(new string[] { mulSplit }, StringSplitOptions.RemoveEmptyEntries);
                    for (int iOuter = 0; iOuter < strSourceMul.Length; iOuter++)
                    {
                        string strSourceItem = mulSplit + strSourceMul[iOuter];
                        strTestTime = DateTime.Now.ToString("yyyyMMdd");
                        #region 样本结果  analysis[8] ORU^R01 analysis[15].Equals("2")
                        string[] analysis = strSourceItem.Split('|');
                        string messageTime = analysis[6];
                        string messageID = analysis[9];
                        if (strSourceItem.Split('|')[8] == "ORU^R01" && strSourceItem.Split('|')[10] == "P")
                        {
                            string ACK_R01_OK = SB + @"MSH|^~\&|||||{0}||ACK^R01|{1}|P|2.3.1||||0||UNICODE|||" + CR + "MSA|AA|{1}|Message accepted|||0|" + CR + EB + CR;
                            strCmd = string.Format(ACK_R01_OK, strTestTime, messageID);
                            string[] strSourceArray = strSource.Split(new char[] { '\r' }, StringSplitOptions.RemoveEmptyEntries);
                            for (int i = 0; i < strSourceArray.Length; i++)
                            {
                                if (strSourceArray[i].Split(new char[] { '|' })[0].Replace("\n", "").Equals("OBR"))
                                {
                                    strSampleNo = strSourceArray[i].Split('|')[3];
                                    string times = strSourceArray[i].Split('|')[6];
                                    strTestTime = times.Substring(0, 4) + "-" + times.Substring(4, 2) + "-" + times.Substring(6, 2);
                                    strBarCode = strSourceArray[i].Split('|')[2].Trim();
                                    if (strBarCode != "") strSampleNo = strBarCode;
                                    //默认路径
                                    path = Directory.GetCurrentDirectory() + @"\Dirui.BF6900.Image\" + strTestTime + @"\";

                                    //样本编号转换为条码号
                                    string returns = Helper.SampleNoToSampleBar(strSampleNo);
                                    if (!string.IsNullOrEmpty(returns))
                                    {
                                        strTestTime = returns.Split('|')[0];
                                        strSampleNo = returns.Split('|')[1];
                                        //strBarCode = strSampleNo;
                                        //修正路径
                                        writelog.Write(strDevice, "strTestTime： " + strTestTime + "|strSampleNo:" + strSampleNo + "|strBarCode:" + strBarCode, "log");
                                        path = Directory.GetCurrentDirectory() + @"\Dirui.BF6900.Image\" + strTestTime + @"\";
                                    }

                                }

                                if (strSourceArray[i].Split(new char[] { '|' })[0].Replace("\n", "").Equals("OBX"))
                                {
                                    string imageItem = strSourceArray[i];
                                    for (int j = 0; j < correspondenceArray.Length; j++)
                                    {
                                        string lis = correspondenceArray[j].Split(',')[0];
                                        string zlchs = correspondenceArray[j].Split(',')[1];
                                        if (strSourceArray[i].IndexOf('|' + lis + '|') > 0)
                                        {
                                            if (zlchs.IndexOf("CRP") != -1)
                                            {
                                                if (strSourceArray[i].Split('|')[5] == "0" ||strSourceArray[i].Split('|')[5] == "0.00") continue;
                                                else
                                                    sBuilder.Append(zlchs.ToUpper() + ',' + strSourceArray[i].Split('|')[5] + '|');
                                            }
                                            else
                                                sBuilder.Append(zlchs.ToUpper() + ',' + strSourceArray[i].Split('|')[5] + '|');
                                        }
                                    }

                                    //RBC Histogram
                                    if (imageItem.IndexOf("|2101") != -1)
                                    {
                                        string s = imageItem.Split('|')[5];
                                        RBC = s;
                                    }
                                    //PLT Histogram
                                    if (imageItem.IndexOf("|2102") != -1)
                                    {
                                        string s = imageItem.Split('|')[5];
                                        PLT = s;
                                    }
                                    //BASO Histogram
                                    if (imageItem.IndexOf("|2033") != -1)
                                    {
                                        string s = imageItem.Split('|')[5];
                                        BASO = s;
                                    }
                                    //DIFF
                                    if (imageItem.IndexOf("|2034") != -1)
                                    {
                                        string s = imageItem.Split('|')[5];
                                        DIFF = s;
                                    }
                                    //调用绘图接口进行图形绘制
                                    //绘图是否成功写入日志                                   
                                    imageName = strSampleNo;
                                }
                            }
                            if (RBC != "")
                            {
                                RBC = ImageHelper.DrawBase64Bitmap(path, imageName + "RBC.bmp", RBC);
                                TestGraph.Add(path + imageName + "RBC.bmp");
                                writelog.Write(strDevice, "RBC:" + RBC, "log");
                            }
                            else
                            {
                                writelog.Write(strDevice, "无图像数据： " + RBC, "log");
                            }
                            if (PLT != "")
                            {
                                PLT = ImageHelper.DrawBase64Bitmap(path, imageName + "PLT.bmp", PLT);
                                TestGraph.Add(path + imageName + "PLT.bmp");
                                writelog.Write(strDevice, "PLT:" + PLT, "log");
                            }
                            else
                            {
                                writelog.Write(strDevice, "无图像数据： " + PLT, "log");
                            }
                            if (BASO != "")
                            {
                                BASO = ImageHelper.DrawBase64Bitmap(path, imageName + "BASO.bmp", BASO);
                                TestGraph.Add(path + imageName + "BASO.bmp");
                                writelog.Write(strDevice, "BASO:" + BASO, "log");
                            }
                            else
                            {
                                writelog.Write(strDevice, "无图像数据： " + BASO, "log");
                            }
                            if (DIFF != "")
                            {
                                DIFF = ImageHelper.DrawBase64Bitmap(path, imageName + "DIFF.bmp", DIFF);
                                TestGraph.Add(path + imageName + "DIFF.bmp");
                                writelog.Write(strDevice, "DIFF:" + DIFF, "log");

                            }
                            else
                            {
                                writelog.Write(strDevice, "无图像数据： " + DIFF, "log");
                            }


                            string str = sBuilder.ToString().Remove(sBuilder.Length - 1);
                            string[] strs = str.Split('|');

                            string ChannelType = "";     //0-普通结果;1-直方图;2-散点图;3-直方图界标;4-散点图界标;5-BASE64
                            string testItemID = "";
                            string TestResultValue = "";
                            for (int i = 0; i < strs.Length; i++)
                            {

                                FindRow = tItemChannel.Select("通道编码='" + strs[i].Split(',')[0] + "'");
                                if (FindRow.Length == 0) //无普通结果则查找图像能道，无图像通道则更新通道类型为空
                                {
                                    ChannelType = null;
                                    writelog.Write(strDevice, "未设置通道：" + strs[i].Split(',')[0], "log");
                                }
                                else
                                {
                                    testItemID = FindRow[0]["项目id"].ToString();
                                    ChannelType = "0"; //普通结果
                                    TestResultValue = TestResultValue + testItemID + "^" + strs[i].Split(',')[1].Replace("RuPT", "阴性") + "|";
                                }

                            }

                            TestResultValue = strTestTime + "|" + strSampleNo + "^" + strSampleType + "^" + strBarCode + "|" + strOperator + "|" + StrSpecimen + "|" + "|" + TestResultValue;
                            saveResult = new SaveResult();
                            if (!string.IsNullOrEmpty(strSampleNo) || !string.IsNullOrEmpty(strBarCode))
                            {
                                saveResult.SaveTextResult(strInstrument_id, TestResultValue, TestGraph, DrSampleNoField);
                                if (ImmediatelyUpdate)
                                {
                                    saveResult.UpdateData();
                                }
                            }

                        }
                        #endregion
                        #region 质控处理
                        if (strSourceItem.Split('|')[8] == "ORU^R01" && strSourceItem.Split('|')[10] == "Q")
                        {
                        }
                        #endregion
                        #region 样本请求处理 双向
                        string orgid = INIHelper.getInstance().IniReadValue("EQUIPMENT", "Agencies");
                        string CheckInUserName = INIHelper.getInstance().IniReadValue("EQUIPMENT", "Inspector");
                        string CheckInUserID = INIHelper.getInstance().IniReadValue("EQUIPMENT", "InspectorID");
                        if (strSourceItem.Split('|')[8] == "ORM^O01")
                        {
                            messageTime = strSourceItem.Split('|')[6];

                            string QCK_Q02_NF, ORR_002;//没有查询到相关到样本信息,应答给仪器 ORR_002是错误,QCK_Q02_NF是没有找到
                            QCK_Q02_NF = SB + @"MSH|^~\&|||||{0}||DSR^Q03|{1}|P|2.3.1||||0||UNICODE|||" + CR
               + "MSA|NF|{1}||||0|" + CR
               + EB + CR;
                            ORR_002 = SB + @"MSH|^~\&|LIS||||{0}||DSR^Q03|{1}|P|2.3.1||||||UNICODE" + CR
                                         + "MSA|AR|1|错误error|||206|" + CR
                                         + EB + CR;
                            //默认发送没有找到
                            strCmd = string.Format(QCK_Q02_NF, strTestTime, messageID);
                            //解析查询样本结果
                            string[] sa = strSourceItem.Split(CR);
                            foreach (string item in sa)
                            {
                                if (item.StartsWith("ORC"))
                                {
                                    strBarCode = item.Split('|')[3];
                                }
                            }
                            if (strBarCode != "")
                            {

                                //查询该条码是否核收 如何没有核收就自动核收

                                //自动核收样本
                                sql = @"select j.id,申请来源,j.性别,年龄数字|| 年龄单位 as 年龄,i.出生日期,样本类型,j.记录状态,j.样本序号
                                from  检验记录 j,个人信息 i where j.机构ID='in_orgid' and j.个人id=i.id(+) and 合并id is null and j.样本序号 is null  and  样本条码='in_strBarCode'";
                                sql = sql.Replace("in_orgid", orgid);
                                sql = sql.Replace("in_strBarCode", strBarCode);
                                DataTable table = OracleHelper.GetDataTable(sql);
                                if (table.Rows.Count != 0)
                                {
                                    if (table.Rows[0]["样本序号"].ToString().Equals(string.Empty))
                                    {
                                        string getSamplenosql = @"select f_生成样本号('in_设备id',1,sysdate) as 样本号 from dual";
                                        getSamplenosql = getSamplenosql.Replace("in_设备id", strDeviceID);

                                        DataTable dt = OracleHelper.GetDataTable(getSamplenosql);
                                        if (dt.Rows.Count > 0)
                                        {
                                            string newSampleno = dt.Rows[0]["样本号"].ToString();
                                            string procedure = "P_检验记录_标本核收";
                                            OracleParameter[] parameter = new OracleParameter[]
                                                    {
                                                     new OracleParameter("ID_IN",DbType.String),
                                                     new OracleParameter("仪器ID_IN",DbType.String),
                                                     new OracleParameter("样本序号_IN",DbType.String),
                                                     new OracleParameter("核收人_IN",DbType.String),
                                                     new OracleParameter("核收人ID_IN",DbType.String)
                                                     
                                                     };
                                            parameter[0].Value = table.Rows[0]["id"];
                                            parameter[1].Value = strDeviceID;
                                            parameter[2].Value = newSampleno;
                                            parameter[3].Value = CheckInUserName;
                                            parameter[4].Value = CheckInUserID;

                                            string msg = "";
                                            OracleHelper.RunProcedure(procedure, parameter, ref msg);
                                            if (msg != "")
                                            {
                                                writelog.Write(strDevice, "样本自动核收失败:" + msg, "log");
                                                writelog.Write(strDevice, "样本自动核收失败sql:" + sql, "log");
                                            }
                                        }

                                    }

                                }
                            }
                            //核收样本后再查询
                            sql = @"select 病人姓名,性别,年龄,出生日期,血型,病人类型,收费类型,住院号,床号,样本条码,to_number(样本编号)  样本编号,样本送检时间,是否急诊,送检医生,送检科室,样本类型,仪器模式,临床诊断,检验备注,wm_concat(项目编号)  项目编号
from
(Select distinct u.姓名 as 病人姓名,
       Decode(u.性别,
              '0',
              '未知的性别',
              '1',
              'M',
              '2',
              'F',
              'M') 性别,
       to_char(u.出生日期, 'yyyymmddhh24miss') as 出生日期,f_get_age(出生日期)   年龄,
       Nvl(s.血型, '不详') 血型,
       Decode(Nvl(z.状态, 0), 1, '门诊', 2, '住院', '体检及其他') 病人类型,
       '' as 收费类型,
       z.住院号,
       z.床号,
       j.样本条码,
       j.样本序号 as 样本编号,
       to_char(j.核收时间, 'yyyymmddhh24miss') as 样本送检时间,
       Decode(Nvl(j.紧急申请, 0), 0, '否', 1, '是') 是否急诊,
       j.核收人 as 送检医生,
       b.简称 送检科室,
       j.样本类型,
       j.仪器模式,
       extractvalue(a.医嘱附注, '/root/diagnosis') As 临床诊断,
       j.检验备注,
       c.通道编码 项目编号
  From 个人信息 u,
       检验记录 j,
       部门 b,
       仪器检测项目 c,
       个人当前状态 z,
       检验申请项目 sq,
       检验报告项目 bg,
       (Select s.个人id, x.名称 血型
          From 个人既往史 s, Abo血型 x
         Where s.结果码 = x.编码(+)
           And s.项目码 = '01') s,
       个人医嘱记录 a
 Where u.Id = j.个人id
   And j.执行科室id(+) = b.资源id 
   and j.id = sq.记录id
   and bg.项目id = sq.项目id
   and a.id(+) = j.id
   and bg.报告项id = c.项目id
   And j.个人id = z.个人id(+)  
   And j.个人id = s.个人id(+) and j.仪器id='in_strDeviceID'  And j.机构id = 'in_orgId' and  j.样本条码 ='in_strBarCode' ) Group By 年龄,病人姓名,性别,出生日期,血型,病人类型,收费类型,住院号,床号,样本条码,样本编号,样本送检时间,是否急诊,送检医生,送检科室,样本类型,仪器模式,临床诊断,检验备注  order by 样本编号 ";

                            sql = sql.Replace("in_strDeviceID", strDeviceID);
                            sql = sql.Replace("in_orgId", orgid);
                            //strBarCode = "1904000263";
                            sql = sql.Replace("in_strBarCode", strBarCode);
                            DataTable dt1 = OracleHelper.GetDataTable(sql);
                            if (dt1.Rows.Count == 0) writelog.Write(strDevice, "样本信息申请失败:" + sql, "log");
                            if (dt1.Rows.Count != 0)
                            {   //组装
                                DataRow row = dt1.Rows[0];
                                string testItem = dt1.Rows[0]["项目编号"].ToString().Replace(",", "^");
                                int testCount = testItem.Split('^').Length;
                                strCmd = @"<SB>MSH|^~\&|LIS||||in_testTime||ORR^O02|4|P^S|2.3.1||||||UTF-8<CR>";
                                strCmd += @"MSA|AA|1||||0<CR>";
                                strCmd += @"PID|1||in_病历号||in_姓名|||in_性别|||||||||||||||||||||||in_年龄^Y<CR>";
                                strCmd += @"PV1|1|||||||||||||||||||<CR>";
                                strCmd += @"ORC|AF|in_样本条码|||<CR>";
                                strCmd += @"OBR|1|in_样本条码|in_样本编号|1001^Count||in_testTime||||in_医生||||in_testTime||||||||||||||<CR>";
                                strCmd += @"OBX|1|IS|2001^MODE||0||||||||<CR>";
                                strCmd += @"OBX|2|IS|2002^MODE_EX||in_mode||||||||<CR>";
                                strCmd += @"OBX|3|IS|2003^Ref||0||||||||<CR>";
                                strCmd += @"OBX|4|ST|2004^Note||test||||||||<CR>";
                                strCmd = strCmd + EB + CR;


                                strCmd = strCmd.Replace("<CR>", CR + "");
                                strCmd = strCmd.Replace("<SB>", SB + "");
                                strCmd = strCmd.Replace("in_testCount", Convert.ToString(testCount));
                                strCmd = strCmd.Replace("in_testItem", Convert.ToString(testItem));
                                int in_mode = 1;

                                bool isCRP = dt1.Rows[0]["项目编号"].ToString().ToUpper().IndexOf("CRP") > -1;
                                bool isCBC = dt1.Rows[0]["项目编号"].ToString().ToUpper().IndexOf("RBC") > -1;
                                bool isDif = dt1.Rows[0]["项目编号"].ToString().ToUpper().IndexOf("NEU_P".ToUpper()) > -1;

                                writelog.Write(strDevice, "项目编号:" + dt1.Rows[0]["项目编号"].ToString(), "log");
                                if (isDif)
                                {
                                    if (isCRP) in_mode = 2;
                                    else in_mode = 1;
                                }
                                else if (isCBC && isCRP)
                                    in_mode = 4;
                                else if (isCBC)
                                    in_mode = 0;
                                else if (isCRP)
                                    in_mode = 3;
                                else
                                {
                                    strCmd = @"<SB>MSH|^~\&|LIS||||in_testTime||ORR^O02|4|P^S|2.3.1||||||UTF-8<CR>";
                                    strCmd += @"MSA|AR|in_messageID||||204<CR>";
                                    strCmd = strCmd + EB + CR;
                                    strCmd = strCmd.Replace("<CR>", CR + "");
                                    strCmd = strCmd.Replace("<SB>", SB + "");
                                    strCmd = strCmd.Replace("in_testTime", strTestFullTime);
                                    strCmd = strCmd.Replace("in_messageID", messageID);
                                    return;
                                }



                                writelog.Write(strDevice, "测试模式:" + in_mode, "log");
                                strCmd = strCmd.Replace("in_mode", in_mode + "");

                                strCmd = strCmd.Replace("in_病历号", row["住院号"].ToString());
                                strCmd = strCmd.Replace("in_姓名", row["病人姓名"].ToString());
                                strCmd = strCmd.Replace("in_序列号", messageID);
                                strCmd = strCmd.Replace("in_性别", row["性别"].ToString());
                                string age = "";
                                if (row["年龄"].ToString().IndexOf("月") != -1 || row["年龄"].ToString().IndexOf("天") != -1)
                                    age = "1";
                                else
                                    age = row["年龄"].ToString().Replace("岁", "");
                                strCmd = strCmd.Replace("in_testTime", strTestFullTime);
                                strCmd = strCmd.Replace("in_年龄", age);
                                strCmd = strCmd.Replace("in_样本条码", strBarCode);
                                strCmd = strCmd.Replace("in_样本编号", row["样本编号"].ToString());
                                strCmd = strCmd.Replace("in_重复次数", "1");

                                strCmd = strCmd.Replace("in_样本类型", row["样本类型"].ToString());
                                strCmd = strCmd.Replace("in_检验医生", CheckInUserName);
                                writelog.Write(strDevice, "样本信息申请strCmd:" + strCmd, "log");

                            }

                        }

                        #endregion

                    }

                }

            }


            catch (Exception ex)
            {
                writelog.Write(strDevice, "处理失败： " + ex.ToString(), "log");
            }
        }



        public System.Drawing.Image LocalIMG(string IMG)
        {
            throw new NotImplementedException();
        }

        public string GetCmd(string dataIn, string ack_term)
        {
            throw new NotImplementedException();
        }

        public void GetRules(string StrDevice)
        {
            DataSet dsTestItem = new DataSet();
            DataSet dsRules = new DataSet();
            strInstrument_id = StrDevice;

            DrTestTimeSignField = null;         //检验时间标识
            DrTestTimeField = null;             //检验时间
            DrSampleNoSignField = null;
            DrSampleNoField = null;
            DrBarCodeSignField = null;
            DrBarCodeField = null;
            DrSampleTypeSignField = null;
            DrSampleTypeField = null;
            DrOperatorSignField = null;
            DrOperatorField = null;
            DrSpecimenSignField = null;
            DrSpecimenField = null;

            DrResultSignField = null;
            DrResultInfoField = null;
            DrResultCountField = null;
            DrSingleResultField = null;
            DrChannelField = null;
            DrResultField = null;

            dsRules = dsHandle.GetDataSet(@"Extractvalue(Column_Value, '/item/item_code') As item_code, Extractvalue(Column_Value, '/item/separated_first') As separated_first, 
                                                   Extractvalue(Column_Value, '/item/no_first') As no_first, Extractvalue(Column_Value, '/item/separated_second') As separated_second,
                                                   Extractvalue(Column_Value, '/item/no_second') As no_second, Extractvalue(Column_Value, '/item/start_bits') As start_bits,
                                                   Extractvalue(Column_Value, '/item/length') As length, Extractvalue(Column_Value, '/item/sign') As sign,Extractvalue(Column_Value, '/item/format') As format",
                                                   "Table(Xmlsequence(Extract((Select 解析规则 From 检验仪器 Where ID = '" + strInstrument_id + "'), '/root/item'))) ", "");
            //检验指标通道            
            //ds_ItemChannel = dsHandle.GetDataSet("通道编码,项目id,nvl(小数位数,2) as 小数位数,nvl(换算比,0) as 换算比", "仪器检测项目", "仪器id = '" + strInstrument_id + "'");
            tItemChannel = OracleHelper.GetDataTable(@"Select 通道编码, m.项目id, Nvl(小数位数, 2) As 小数位数, Nvl(换算比, 0) As 换算比, Nvl(加算值, 0) As 加算值, j.结果类型
                                        From 仪器检测项目 m, 检验项目 j
                                        Where m.项目id = j.项目id and m.仪器Id='" + StrDevice + "'");
            ds_ItemChannel.CaseSensitive = true;
            //检验图像通道
            //ds_GraphChannel = dsHandle.GetDataSet("CHANNEL_NO,GRAPH_TYPE", "TEST_GRAPH_CHANNEL", "instrument_id = '" + strInstrument_id + "'");
            //ds_GraphChannel.CaseSensitive = true;

            FindRow = dsRules.Tables[0].Select("item_code = '01'");         //检验日期标识
            if (FindRow.Length != 0) DrTestTimeSignField = FindRow[0];
            FindRow = dsRules.Tables[0].Select("item_code = '02'");             //检验日期
            if (FindRow.Length != 0) DrTestTimeField = FindRow[0];
            FindRow = dsRules.Tables[0].Select("item_code = '03'");       //常规样本号标识
            if (FindRow.Length != 0) DrSampleNoSignField = FindRow[0];
            FindRow = dsRules.Tables[0].Select("item_code = '04'");           //常规样本号
            if (FindRow.Length != 0) DrSampleNoField = FindRow[0];
            else
            {
                DrSampleNoField = null;
            }
            FindRow = dsRules.Tables[0].Select("item_code = '05'");      //质控样本号
            if (FindRow.Length != 0) DrQCSampleField = FindRow[0];
            FindRow = dsRules.Tables[0].Select("item_code = '06'");        //条码号标识
            if (FindRow.Length != 0) DrBarCodeSignField = FindRow[0];
            FindRow = dsRules.Tables[0].Select("item_code = '07'");        //条码号
            if (FindRow.Length != 0) DrBarCodeField = FindRow[0];
            FindRow = dsRules.Tables[0].Select("item_code = '08'");        //样本类型标识
            if (FindRow.Length != 0) DrSampleTypeSignField = FindRow[0];
            FindRow = dsRules.Tables[0].Select("item_code = '09'");        //样本类型
            if (FindRow.Length != 0) DrSampleTypeField = FindRow[0];
            FindRow = dsRules.Tables[0].Select("item_code = '10'");        //检验人标识
            if (FindRow.Length != 0) DrOperatorSignField = FindRow[0];
            FindRow = dsRules.Tables[0].Select("item_code = '11'");        //检验人
            if (FindRow.Length != 0) DrOperatorField = FindRow[0];
            FindRow = dsRules.Tables[0].Select("item_code = '12'");        //标本标识
            if (FindRow.Length != 0) DrSpecimenSignField = FindRow[0];
            FindRow = dsRules.Tables[0].Select("item_code = '13'");        //标本
            if (FindRow.Length != 0) DrSpecimenField = FindRow[0];

            FindRow = dsRules.Tables[0].Select("item_code = '14'");        //结果标识
            if (FindRow.Length != 0) DrResultSignField = FindRow[0];
            FindRow = dsRules.Tables[0].Select("item_code = '15'");        //结果信息
            if (FindRow.Length != 0) DrResultInfoField = FindRow[0];
            FindRow = dsRules.Tables[0].Select("item_code = '16'");        //结果数
            if (FindRow.Length != 0) DrResultCountField = FindRow[0];
            FindRow = dsRules.Tables[0].Select("item_code = '17'");      //单个结果
            if (FindRow.Length != 0) DrSingleResultField = FindRow[0];
            FindRow = dsRules.Tables[0].Select("item_code = '18'");        //通道号
            if (FindRow.Length != 0) DrChannelField = FindRow[0];
            FindRow = dsRules.Tables[0].Select("item_code = '19'");        //结果值
            if (FindRow.Length != 0) DrResultField = FindRow[0];
            FindRow = dsRules.Tables[0].Select("item_code = '20'");        //盘号
            //if (FindRow.Length != 0) Field_Row[4] = FindRow[0];
            FindRow = dsRules.Tables[0].Select("item_code = '21'");        //杯号
            //if (FindRow.Length != 0) Field_Row[5] = FindRow[0];
            strDeviceID = StrDevice;
            strDevice = OracleHelper.GetDataTable("select 名称 from 检验仪器 where id='" + StrDevice + "'").Rows[0]["名称"].ToString();
        }

        public void SetVariable(System.Data.DataTable dt)
        {
            throw new NotImplementedException();
        }
    }
}
